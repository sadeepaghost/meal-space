import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TransactionsRecord extends FirestoreRecord {
  TransactionsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "type" field.
  String? _type;

  /// topup
  /// widhraw
  /// transer
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "amount" field.
  double? _amount;
  double get amount => _amount ?? 0.0;
  bool hasAmount() => _amount != null;

  // "from_user_ref" field.
  DocumentReference? _fromUserRef;
  DocumentReference? get fromUserRef => _fromUserRef;
  bool hasFromUserRef() => _fromUserRef != null;

  // "to_user_ref" field.
  DocumentReference? _toUserRef;
  DocumentReference? get toUserRef => _toUserRef;
  bool hasToUserRef() => _toUserRef != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "stripe_charge_id" field.
  String? _stripeChargeId;
  String get stripeChargeId => _stripeChargeId ?? '';
  bool hasStripeChargeId() => _stripeChargeId != null;

  // "bankAccount" field.
  int? _bankAccount;
  int get bankAccount => _bankAccount ?? 0;
  bool hasBankAccount() => _bankAccount != null;

  void _initializeFields() {
    _type = snapshotData['type'] as String?;
    _amount = castToType<double>(snapshotData['amount']);
    _fromUserRef = snapshotData['from_user_ref'] as DocumentReference?;
    _toUserRef = snapshotData['to_user_ref'] as DocumentReference?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _stripeChargeId = snapshotData['stripe_charge_id'] as String?;
    _bankAccount = castToType<int>(snapshotData['bankAccount']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('transactions');

  static Stream<TransactionsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TransactionsRecord.fromSnapshot(s));

  static Future<TransactionsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TransactionsRecord.fromSnapshot(s));

  static TransactionsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TransactionsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TransactionsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TransactionsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TransactionsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TransactionsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTransactionsRecordData({
  String? type,
  double? amount,
  DocumentReference? fromUserRef,
  DocumentReference? toUserRef,
  DateTime? timestamp,
  String? stripeChargeId,
  int? bankAccount,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'type': type,
      'amount': amount,
      'from_user_ref': fromUserRef,
      'to_user_ref': toUserRef,
      'timestamp': timestamp,
      'stripe_charge_id': stripeChargeId,
      'bankAccount': bankAccount,
    }.withoutNulls,
  );

  return firestoreData;
}

class TransactionsRecordDocumentEquality
    implements Equality<TransactionsRecord> {
  const TransactionsRecordDocumentEquality();

  @override
  bool equals(TransactionsRecord? e1, TransactionsRecord? e2) {
    return e1?.type == e2?.type &&
        e1?.amount == e2?.amount &&
        e1?.fromUserRef == e2?.fromUserRef &&
        e1?.toUserRef == e2?.toUserRef &&
        e1?.timestamp == e2?.timestamp &&
        e1?.stripeChargeId == e2?.stripeChargeId &&
        e1?.bankAccount == e2?.bankAccount;
  }

  @override
  int hash(TransactionsRecord? e) => const ListEquality().hash([
        e?.type,
        e?.amount,
        e?.fromUserRef,
        e?.toUserRef,
        e?.timestamp,
        e?.stripeChargeId,
        e?.bankAccount
      ]);

  @override
  bool isValidKey(Object? o) => o is TransactionsRecord;
}
