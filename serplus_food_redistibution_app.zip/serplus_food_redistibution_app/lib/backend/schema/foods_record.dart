import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FoodsRecord extends FirestoreRecord {
  FoodsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "food_name" field.
  String? _foodName;
  String get foodName => _foodName ?? '';
  bool hasFoodName() => _foodName != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  // "remaining_portion" field.
  int? _remainingPortion;
  int get remainingPortion => _remainingPortion ?? 0;
  bool hasRemainingPortion() => _remainingPortion != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "food_category" field.
  String? _foodCategory;
  String get foodCategory => _foodCategory ?? '';
  bool hasFoodCategory() => _foodCategory != null;

  // "seller_uid" field.
  DocumentReference? _sellerUid;
  DocumentReference? get sellerUid => _sellerUid;
  bool hasSellerUid() => _sellerUid != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "food_image" field.
  String? _foodImage;
  String get foodImage => _foodImage ?? '';
  bool hasFoodImage() => _foodImage != null;

  // "food_preference" field.
  String? _foodPreference;
  String get foodPreference => _foodPreference ?? '';
  bool hasFoodPreference() => _foodPreference != null;

  // "available_time_from" field.
  DateTime? _availableTimeFrom;
  DateTime? get availableTimeFrom => _availableTimeFrom;
  bool hasAvailableTimeFrom() => _availableTimeFrom != null;

  // "available_time_to" field.
  DateTime? _availableTimeTo;
  DateTime? get availableTimeTo => _availableTimeTo;
  bool hasAvailableTimeTo() => _availableTimeTo != null;

  // "real_price" field.
  double? _realPrice;
  double get realPrice => _realPrice ?? 0.0;
  bool hasRealPrice() => _realPrice != null;

  void _initializeFields() {
    _foodName = snapshotData['food_name'] as String?;
    _price = castToType<double>(snapshotData['price']);
    _remainingPortion = castToType<int>(snapshotData['remaining_portion']);
    _description = snapshotData['description'] as String?;
    _foodCategory = snapshotData['food_category'] as String?;
    _sellerUid = snapshotData['seller_uid'] as DocumentReference?;
    _location = snapshotData['location'] as LatLng?;
    _foodImage = snapshotData['food_image'] as String?;
    _foodPreference = snapshotData['food_preference'] as String?;
    _availableTimeFrom = snapshotData['available_time_from'] as DateTime?;
    _availableTimeTo = snapshotData['available_time_to'] as DateTime?;
    _realPrice = castToType<double>(snapshotData['real_price']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('foods');

  static Stream<FoodsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FoodsRecord.fromSnapshot(s));

  static Future<FoodsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FoodsRecord.fromSnapshot(s));

  static FoodsRecord fromSnapshot(DocumentSnapshot snapshot) => FoodsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FoodsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FoodsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FoodsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FoodsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFoodsRecordData({
  String? foodName,
  double? price,
  int? remainingPortion,
  String? description,
  String? foodCategory,
  DocumentReference? sellerUid,
  LatLng? location,
  String? foodImage,
  String? foodPreference,
  DateTime? availableTimeFrom,
  DateTime? availableTimeTo,
  double? realPrice,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'food_name': foodName,
      'price': price,
      'remaining_portion': remainingPortion,
      'description': description,
      'food_category': foodCategory,
      'seller_uid': sellerUid,
      'location': location,
      'food_image': foodImage,
      'food_preference': foodPreference,
      'available_time_from': availableTimeFrom,
      'available_time_to': availableTimeTo,
      'real_price': realPrice,
    }.withoutNulls,
  );

  return firestoreData;
}

class FoodsRecordDocumentEquality implements Equality<FoodsRecord> {
  const FoodsRecordDocumentEquality();

  @override
  bool equals(FoodsRecord? e1, FoodsRecord? e2) {
    return e1?.foodName == e2?.foodName &&
        e1?.price == e2?.price &&
        e1?.remainingPortion == e2?.remainingPortion &&
        e1?.description == e2?.description &&
        e1?.foodCategory == e2?.foodCategory &&
        e1?.sellerUid == e2?.sellerUid &&
        e1?.location == e2?.location &&
        e1?.foodImage == e2?.foodImage &&
        e1?.foodPreference == e2?.foodPreference &&
        e1?.availableTimeFrom == e2?.availableTimeFrom &&
        e1?.availableTimeTo == e2?.availableTimeTo &&
        e1?.realPrice == e2?.realPrice;
  }

  @override
  int hash(FoodsRecord? e) => const ListEquality().hash([
        e?.foodName,
        e?.price,
        e?.remainingPortion,
        e?.description,
        e?.foodCategory,
        e?.sellerUid,
        e?.location,
        e?.foodImage,
        e?.foodPreference,
        e?.availableTimeFrom,
        e?.availableTimeTo,
        e?.realPrice
      ]);

  @override
  bool isValidKey(Object? o) => o is FoodsRecord;
}
