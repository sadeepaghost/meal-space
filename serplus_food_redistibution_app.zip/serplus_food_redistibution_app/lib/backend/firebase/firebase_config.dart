import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDQ-a1pStnA3OHXiGcvUAIHhaTXtkCNz_E",
            authDomain: "serplus-food-redistibut-h3c9y3.firebaseapp.com",
            projectId: "serplus-food-redistibut-h3c9y3",
            storageBucket: "serplus-food-redistibut-h3c9y3.firebasestorage.app",
            messagingSenderId: "379441210223",
            appId: "1:379441210223:web:058999a0e445fc70c63e9a"));
  } else {
    await Firebase.initializeApp();
  }
}
