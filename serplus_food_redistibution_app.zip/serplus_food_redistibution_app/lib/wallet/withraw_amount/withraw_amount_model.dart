import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/wallet/password_confirmation/password_confirmation_widget.dart';
import 'dart:ui';
import 'withraw_amount_widget.dart' show WithrawAmountWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WithrawAmountModel extends FlutterFlowModel<WithrawAmountWidget> {
  ///  State fields for stateful widgets in this component.

  // State field(s) for accountNumber widget.
  FocusNode? accountNumberFocusNode;
  TextEditingController? accountNumberTextController;
  String? Function(BuildContext, String?)? accountNumberTextControllerValidator;
  // State field(s) for amountText widget.
  FocusNode? amountTextFocusNode;
  TextEditingController? amountTextTextController;
  String? Function(BuildContext, String?)? amountTextTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    accountNumberFocusNode?.dispose();
    accountNumberTextController?.dispose();

    amountTextFocusNode?.dispose();
    amountTextTextController?.dispose();
  }
}
