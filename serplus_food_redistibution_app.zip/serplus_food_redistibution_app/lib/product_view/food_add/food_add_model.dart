import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_google_map.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'food_add_widget.dart' show FoodAddWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FoodAddModel extends FlutterFlowModel<FoodAddWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading_uploadData0w1 = false;
  FFUploadedFile uploadedLocalFile_uploadData0w1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadData0w1 = '';

  // State field(s) for F_cat widget.
  String? fCatValue;
  FormFieldController<String>? fCatValueController;
  // State field(s) for F_pre widget.
  String? fPreValue;
  FormFieldController<String>? fPreValueController;
  // State field(s) for FoodName widget.
  FocusNode? foodNameFocusNode;
  TextEditingController? foodNameTextController;
  String? Function(BuildContext, String?)? foodNameTextControllerValidator;
  // State field(s) for DiscountPrice widget.
  FocusNode? discountPriceFocusNode;
  TextEditingController? discountPriceTextController;
  String? Function(BuildContext, String?)? discountPriceTextControllerValidator;
  // State field(s) for ActualPrice widget.
  FocusNode? actualPriceFocusNode;
  TextEditingController? actualPriceTextController;
  String? Function(BuildContext, String?)? actualPriceTextControllerValidator;
  // State field(s) for numberOfPotion widget.
  FocusNode? numberOfPotionFocusNode;
  TextEditingController? numberOfPotionTextController;
  String? Function(BuildContext, String?)?
      numberOfPotionTextControllerValidator;
  // State field(s) for Description widget.
  FocusNode? descriptionFocusNode;
  TextEditingController? descriptionTextController;
  String? Function(BuildContext, String?)? descriptionTextControllerValidator;
  DateTime? datePicked1;
  DateTime? datePicked2;
  // State field(s) for GoogleMap widget.
  LatLng? googleMapsCenter;
  final googleMapsController = Completer<GoogleMapController>();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    foodNameFocusNode?.dispose();
    foodNameTextController?.dispose();

    discountPriceFocusNode?.dispose();
    discountPriceTextController?.dispose();

    actualPriceFocusNode?.dispose();
    actualPriceTextController?.dispose();

    numberOfPotionFocusNode?.dispose();
    numberOfPotionTextController?.dispose();

    descriptionFocusNode?.dispose();
    descriptionTextController?.dispose();
  }
}
