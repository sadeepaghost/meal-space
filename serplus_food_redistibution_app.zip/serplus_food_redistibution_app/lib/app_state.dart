import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  bool _termsAccepted = false;
  bool get termsAccepted => _termsAccepted;
  set termsAccepted(bool value) {
    _termsAccepted = value;
  }

  bool _isFieldFill = false;
  bool get isFieldFill => _isFieldFill;
  set isFieldFill(bool value) {
    _isFieldFill = value;
  }

  double _withrawAmount = 0.0;
  double get withrawAmount => _withrawAmount;
  set withrawAmount(double value) {
    _withrawAmount = value;
  }

  bool _isWithdrawMoneyEnough = false;
  bool get isWithdrawMoneyEnough => _isWithdrawMoneyEnough;
  set isWithdrawMoneyEnough(bool value) {
    _isWithdrawMoneyEnough = value;
  }
}
